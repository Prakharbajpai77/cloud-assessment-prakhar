# Prakhar_Bajpai_AWS_Assessment

This repository contains Terraform templates, user-data scripts and README guidance for the Cloud Engineer Internship technical assessment.
Replace 'FirstName_Lastname' tags with your actual first and last name before applying.

Folders:
- Q1_VPC_Setup
- Q2_EC2_Static_Website
- Q3_HA_AutoScaling
- Q4_Billing_Alerts
- Q5_Architecture_Diagram

Files were generated on behalf of Prakhar_Bajpai_AWS_Assessment (prakharbajpai727504@gmail.com).
