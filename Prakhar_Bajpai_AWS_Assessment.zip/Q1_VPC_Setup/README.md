Networking & Subnetting (VPC Setup) - Explanation (4-6 lines)
I designed a single VPC with a /16 CIDR to provide plenty of private address space and to keep subdivisions simple. Two public and two private subnets are created across two Availability Zones for high availability. An Internet Gateway is attached to allow inbound/outbound internet for public subnets; a NAT Gateway in a public subnet is used to allow outbound internet for instances in private subnets. Route tables are associated such that public subnets route 0.0.0.0/0 via the IGW and private subnets route via the NAT Gateway.


Subnet CIDR choices:
VPC: 10.0.0.0/16
Public A: 10.0.1.0/24
Public B: 10.0.2.0/24
Private A: 10.0.11.0/24
Private B: 10.0.12.0/24
