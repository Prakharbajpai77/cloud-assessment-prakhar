AWS Architecture Diagram - Explanation (5-8 lines)
The architecture uses an Internet-facing ALB distributing traffic to an Auto Scaling Group of web servers in private subnets across multiple AZs. A managed RDS/Aurora cluster in private subnets provides the scalable relational database, while ElastiCache (Redis) handles caching for session and read-heavy operations. Security is enforced with Security Groups and NACLs; WAF can be added at the ALB layer for protection. Observability is provided via CloudWatch metrics and centralized logs; S3 and IAM policies are used for static assets and least-privilege access.


Please create a draw.io diagram with the included explanation. You can export as PNG and add to this folder.