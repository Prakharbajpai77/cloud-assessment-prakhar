Billing & Free Tier Cost Monitoring - Explanation (4-6 lines)
Configure an Amazon CloudWatch billing alarm for estimated charges in INR and enable Free Tier usage alerts from the Billing console. Billing alerts notify when charges approach thresholds and Free Tier alerts warn when Free Tier limits are being consumed. This helps beginners avoid unexpected costs caused by accidentally leaving resources running or using non-Free Tier services.


Instructions: Create CloudWatch billing alarm for EstimatedCharges using the AWS console and enable Free Tier alerts from Billing > Free Tier.