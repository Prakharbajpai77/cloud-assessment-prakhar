#!/bin/bash
# Install nginx and deploy resume HTML
yum update -y
yum install -y nginx
systemctl enable nginx
cat > /usr/share/nginx/html/index.html <<'EOF'
<!doctype html>
<html>
<head><meta charset="utf-8"><title>Prakhar Bajpai - Resume</title></head>
<body>
<h1>Prakhar Bajpai</h1>
<p>Full Stack Developer | MCA (Pursuing)</p>
<!-- Add more resume content or link to hosted PDF -->
</body>
</html>
EOF
systemctl start nginx
